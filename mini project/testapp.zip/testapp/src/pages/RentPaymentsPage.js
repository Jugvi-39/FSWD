export default function RentPaymentsPage() {
  return <h1 className="main-title">Rent Payments Page</h1>;
}
