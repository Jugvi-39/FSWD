export default function TenantsPage() {
  return <h1 className="main-title">Tenants Page</h1>;
}
