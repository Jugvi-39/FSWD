export default function PropertiesPage() {
  return <h1 className="main-title">Properties Page</h1>;
}
