export default function LeasePage() {
  return <h1 className="main-title">Lease Agreements Page</h1>;
}
