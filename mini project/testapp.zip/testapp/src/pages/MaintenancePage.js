export default function MaintenancePage() {
  return <h1 className="main-title">Maintenance Requests Page</h1>;
}
